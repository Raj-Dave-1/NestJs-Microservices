import { Inject, Injectable } from '@nestjs/common';
import { User } from './user.dto';
import { ClientProxy } from '@nestjs/microservices';
import { lastValueFrom } from 'rxjs';

@Injectable()
export class AppService {
  constructor(@Inject('Service2') private service2Client: ClientProxy) {}
  sadhuJi(data: User): string {
    console.log('new user created with data: ', data);
    return 'sita ram from service 1!';
  }

  async callBothService(data: User) {
    //----------- TCP call to service 2 -> event (not req-res)  -----------
    await lastValueFrom(
      this.service2Client.emit({ cmd: 'send-notification' }, data),
    );

    //----------- TCP call to service 2-> request response -----------
    return await lastValueFrom(
      this.service2Client.send({ cmd: 'store-log' }, data),
    );
  }
}
