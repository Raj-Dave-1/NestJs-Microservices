// Dada Ki Jay Ho

import { Controller } from '@nestjs/common';
@Controller()
export class AppController {}
