import { Controller } from '@nestjs/common';
import { AppService } from './app.service';
import { EventPattern, MessagePattern } from '@nestjs/microservices';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @MessagePattern({ cmd: 'sadhuJi' })
  sadhuJi(): string {
    console.log('sadhuJi called from service 2');
    return this.appService.sadhuJi();
  }

  @EventPattern({ cmd: 'send-notification' })
  sendNotification(data) {
    console.log('sendNotification called for data: ', data);
  }

  @MessagePattern({ cmd: 'store-log' })
  storeCreateUserLog(data) {
    console.log('storeCreateUserLog called for data: ', data);
    return 'logs stored';
  }
}
