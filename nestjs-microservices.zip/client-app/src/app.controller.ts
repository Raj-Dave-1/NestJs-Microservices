import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { AppService } from './app.service';
import { User } from './user.dto';
import { HttpService } from '@nestjs/axios';

@Controller()
export class AppController {
  constructor(
    private readonly httpService: HttpService,
    private readonly appService: AppService,
  ) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @Post('call-service-1')
  callService1(@Body() data: User) {
    console.log('callService1 called from client');
    return this.appService.callService1(data).toPromise();
  }

  @Post('new-user')
  newUser(@Body() data: User) {
    console.log('newUser called from client');
    return this.appService.newUser(data).toPromise();
  }

  @Get('/users/:id')
  findUserById(@Param('id') id: number) {
    return this.appService.callService3(id);
  }
}
