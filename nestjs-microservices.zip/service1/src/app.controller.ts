// Dada Ki Jay Ho

import { Controller } from '@nestjs/common';
import { AppService } from './app.service';
import { MessagePattern } from '@nestjs/microservices';
import { User } from './user.dto';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @MessagePattern({ cmd: 'sadhuJi' })
  sadhuJi(data: User): string {
    console.log('sadhuJi called from service 1');
    return this.appService.sadhuJi(data);
  }

  @MessagePattern({ cmd: 'new-user' })
  callBothService(data: User) {
    console.log('reached service 1');
    return this.appService.callBothService(data);
  }
}
