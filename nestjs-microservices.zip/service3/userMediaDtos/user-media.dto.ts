// Dada Ki Jay Ho

export interface UserMedia {
  id: number;
  url: string;
}
