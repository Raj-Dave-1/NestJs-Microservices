// Dada Ki Jay Ho

import { Inject, Injectable } from '@nestjs/common';
import { ClientGrpc, ClientProxy } from '@nestjs/microservices';
import { User } from './user.dto';
import { UserMediaService } from './proto/user-media/user-media';

@Injectable()
export class AppService {
  private service3GrpcClient: UserMediaService;

  constructor(
    @Inject('Service 1') private readonly service1Client: ClientProxy,
    @Inject('Service 3') private client: ClientGrpc,
  ) {}

  onModuleInit() {
    this.service3GrpcClient =
      this.client.getService<UserMediaService>('UserMediaService');
  }

  getHello(): string {
    return 'Hello World!';
  }

  // ----------- NORMAL HTTP Call to Service ( not microservice ) -----------
  // httpCall() {
  //   console.log('reached to client for httpCall to microservice1');
  //   const response = lastValueFrom(
  //     this.httpService.get('http://localhost:PORT/httpCall'),
  //   );
  //   console.log('response: ', await response);

  //   return 'sitaram';
  // }

  //----------- TCP call to service 1-> request response -----------
  callService1(data: User) {
    return this.service1Client.send({ cmd: 'sadhuJi' }, data);
  }

  //----------- TCP call to service 1 -> request response -----------
  newUser(data: User) {
    return this.service1Client.send({ cmd: 'new-user' }, data);
  }

  //----------- gRPC call to service 3 -----------
  callService3(id: number) {
    return this.service3GrpcClient.findOne({ id });
  }
}
