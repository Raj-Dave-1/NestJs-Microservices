import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  sadhuJi(): string {
    return 'sita ram from service 2!';
  }
}
