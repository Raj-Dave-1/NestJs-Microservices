// Dada Ki Jay Ho

import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { HttpModule } from '@nestjs/axios';

const service2Host = 'localhost';
const service2Port = 3001;

@Module({
  imports: [
    HttpModule,
    ClientsModule.register([
      {
        name: 'Service2',
        transport: Transport.TCP,
        options: {
          host: service2Host,
          port: service2Port,
        },
      },
    ]),
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
