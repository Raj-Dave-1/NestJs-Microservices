// Dada Ki Jay Ho

export interface UserMediaId {
  id: number;
}
