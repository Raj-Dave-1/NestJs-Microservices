// Dada Ki Jay Ho

import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { MicroserviceOptions, Transport } from '@nestjs/microservices';
import { join } from 'path';

async function bootstrap() {
  const port = 3002;
  const app = await NestFactory.createMicroservice<MicroserviceOptions>(
    AppModule,
    {
      transport: Transport.GRPC,
      options: {
        package: 'userMedia',
        protoPath: join(__dirname, '../proto/user-media/user-media.proto'),
      },
    },
  );
  await app.listen();
  console.log(`starting service 2 on internal port: ${port} ...`);
}
bootstrap();
