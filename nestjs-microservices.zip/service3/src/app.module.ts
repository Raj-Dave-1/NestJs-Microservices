import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserMediaService } from './user-media.controller';

@Module({
  imports: [],
  controllers: [AppController, UserMediaService],
  providers: [AppService],
})
export class AppModule {}
