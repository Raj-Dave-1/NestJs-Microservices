// Dada Ki Jay Ho

import { Controller } from '@nestjs/common';
import { AppService } from './app.service';
import { GrpcMethod } from '@nestjs/microservices';
// import { Metadata, ServerUnaryCall } from '@grpc/grpc-js';
import { UserMediaId } from 'userMediaDtos/user-media-id.dto';
import { UserMedia } from 'userMediaDtos/user-media.dto';

@Controller()
export class UserMediaService {
  constructor(private readonly appService: AppService) {}
  userMedias = [
    {
      id: 1,
      url: 'https://unsplash.com/photos/a-couple-of-people-that-are-walking-in-the-dirt-igw-14UnNjg',
    },
    {
      id: 2,
      url: 'https://unsplash.com/photos/a-woman-is-walking-in-front-of-a-garage-door-dGFY8zgKR0Q',
    },
  ];

  @GrpcMethod('UserMediaService', 'findOne')
  findOne(
    data: UserMediaId,
    // metadata: Metadata,
    // call: ServerUnaryCall<any, any>,
  ): UserMedia {
    console.log(
      'gRPC call made for UserMediaService.findOne for id: ',
      data.id,
    );
    return this.userMedias.find(({ id }) => id === data.id);
  }
}
