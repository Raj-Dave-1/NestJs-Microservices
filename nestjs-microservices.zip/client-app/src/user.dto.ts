// Dada Ki Jay Ho

export class User {
  email: string;
  password: string;
}
